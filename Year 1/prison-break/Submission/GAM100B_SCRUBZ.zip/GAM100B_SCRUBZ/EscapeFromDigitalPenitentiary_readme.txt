GAME NAME: Escape From Digital Penitentiary
TEAM NAME: SCRUBS
CLASS: GAM100B

TEAM
SAKTHIISH S/O VIJAYADASS	s.sakthiish@digipen.edu	
XIE HAO ZHE			haozhe.xie@digipen.edu	
CHONG JUN YI			junyi.chong@digipen.edu	
BENJAMIN LIEW			benjamin.liew@digipen.edu	

DESCRIPTION
* A Prison Break game where the player explores the map, obtain certain objects to aid their escape, without detection from guards.

* Instructions/Controls can be referred to in game instruction page and tutorial level

IMPORTANT!
* Before starting the game program, please make sure the following folders 
are in the same directory as EscapeFromDigitalPenitentiary.exe
* Those folders/files can be found in "/SOURCE" folder
- "/Audio" 		folder
- "/TxtResource" 	folder
- "/fmod.dll" 		extension


Thank You for playing our game!

