# Tiny DDS File Loader

Simpl DDS file loader.

## See also

https://github.com/Microsoft/DirectXTex
